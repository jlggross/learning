vgchartzfull is a python script based on BeautifulSoup.
It creates a dataset based on data from 
http://www.vgchartz.com/gamedb/

The dataset is saved as vgsales.csv.

You will need to have BeautifulSoup added.
It can be installed by pip.

sudo pip install BeautifulSoup

Thanks to Chris Albon.
http://chrisalbon.com/python/beautiful_soup_scrape_table.html
